// ============================================================================
// udp.cpp — implementation
// ============================================================================
#include "udp.h"
#include "../core/log.h"

#ifdef _WIN32
  #pragma comment(lib, "ws2_32.lib")
#else
  #include <cerrno>
#endif

namespace sg {

static int g_netInitCount = 0;

bool netPlatformInit() {
#ifdef _WIN32
    if (g_netInitCount == 0) {
        WSADATA wsa;
        if (WSAStartup(MAKEWORD(2, 2), &wsa) != 0) {
            logErr("WSAStartup failed");
            return false;
        }
    }
#endif
    g_netInitCount++;
    return true;
}

void netPlatformShutdown() {
#ifdef _WIN32
    g_netInitCount--;
    if (g_netInitCount <= 0) { WSACleanup(); g_netInitCount = 0; }
#endif
}

bool UdpSocket::open(uint16_t port, bool allowBroadcast, bool joinMulticast) {
    netPlatformInit();
    sock = ::socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
    if (sock == SOCK_INVALID) { logErr("socket() failed"); return false; }

    // Non-blocking
#ifdef _WIN32
    u_long nb = 1;
    ioctlsocket(sock, FIONBIO, &nb);
#else
    int fl = fcntl(sock, F_GETFL, 0);
    fcntl(sock, F_SETFL, fl | O_NONBLOCK);
#endif

    int reuse = 1;
    setsockopt(sock, SOL_SOCKET, SO_REUSEADDR, (const char*)&reuse, sizeof(reuse));
#ifdef SO_REUSEPORT
    setsockopt(sock, SOL_SOCKET, SO_REUSEPORT, (const char*)&reuse, sizeof(reuse));
#endif
    if (allowBroadcast) {
        int bc = 1;
        setsockopt(sock, SOL_SOCKET, SO_BROADCAST, (const char*)&bc, sizeof(bc));
    }

    sockaddr_in addr{};
    addr.sin_family = AF_INET;
    addr.sin_addr.s_addr = INADDR_ANY;
    addr.sin_port = htons(port);
    if (::bind(sock, (sockaddr*)&addr, sizeof(addr)) != 0) {
#ifndef _WIN32
        logWarn("bind port %u failed: %s", (unsigned)port, strerror(errno));
#else
        logWarn("bind port %u failed", (unsigned)port);
#endif
        close();
        return false;
    }
    localPort = port;

    if (joinMulticast) {
        ip_mreq mreq{};
        mreq.imr_multiaddr.s_addr = MULTICAST_GROUP; // stored network order
        mreq.imr_interface.s_addr = INADDR_ANY;
        if (setsockopt(sock, IPPROTO_IP, IP_ADD_MEMBERSHIP, (const char*)&mreq, sizeof(mreq)) != 0) {
            logWarn("multicast join failed (continuing without)");
        } else {
            logInfo("joined multicast discovery group 239.27.47.47");
        }
        // Allow loopback of multicast so several clients on one PC see each other
        unsigned char loop = 1;
        setsockopt(sock, IPPROTO_IP, IP_MULTICAST_LOOP, (const char*)&loop, sizeof(loop));
    }
    return true;
}

void UdpSocket::close() {
    if (sock != SOCK_INVALID) {
#ifdef _WIN32
        closesocket(sock);
#else
        ::close(sock);
#endif
        sock = SOCK_INVALID;
    }
}

int UdpSocket::sendTo(const void* data, size_t len, uint32_t ipBE, uint16_t port) {
    if (sock == SOCK_INVALID) return -1;
    sockaddr_in dst{};
    dst.sin_family = AF_INET;
    dst.sin_addr.s_addr = ipBE;
    dst.sin_port = htons(port);
    int r = ::sendto(sock, (const char*)data, (int)len, 0, (sockaddr*)&dst, sizeof(dst));
    return r;
}

int UdpSocket::sendToAddr(const void* data, size_t len, const PeerAddr& a) {
    return sendTo(data, len, a.ip, a.port);
}

int UdpSocket::broadcast(const void* data, size_t len, uint16_t port) {
    return sendTo(data, len, BROADCAST_ADDR, port);
}

int UdpSocket::multicast(const void* data, size_t len, uint16_t port) {
    if (sock == SOCK_INVALID) return -1;
    unsigned char ttl = 2;
    setsockopt(sock, IPPROTO_IP, IP_MULTICAST_TTL, (const char*)&ttl, sizeof(ttl));
    return sendTo(data, len, MULTICAST_GROUP, port);
}

int UdpSocket::recvFrom(void* out, size_t cap, uint32_t& ipBE, uint16_t& port) {
    if (sock == SOCK_INVALID) return -1;
    sockaddr_in src{};
    socklen_t slen = sizeof(src);
    int r = ::recvfrom(sock, (char*)out, (int)cap, 0, (sockaddr*)&src, &slen);
    if (r > 0) {
        ipBE = src.sin_addr.s_addr;
        port = ntohs(src.sin_port);
        return r;
    }
#ifdef _WIN32
    int e = WSAGetLastError();
    if (e == WSAEWOULDBLOCK || e == WSAEMSGSIZE || e == WSAECONNRESET) return 0;
    return -1;
#else
    if (errno == EAGAIN || errno == EWOULDBLOCK) return 0;
    if (errno == ECONNREFUSED) return 0; // ICMP port unreachable on connected-less socket
    return -1;
#endif
}

uint32_t UdpSocket::ipFromString(const std::string& s) {
    in_addr a{};
    if (inet_pton(AF_INET, s.c_str(), &a) == 1) return a.s_addr;
    return 0;
}

std::string UdpSocket::ipToString(uint32_t ipBE) {
    in_addr a{};
    a.s_addr = ipBE;
    char buf[INET_ADDRSTRLEN] = {0};
    inet_ntop(AF_INET, &a, buf, sizeof(buf));
    return std::string(buf);
}

} // namespace sg
