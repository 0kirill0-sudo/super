// ============================================================================
// udp.h — Cross-platform non-blocking UDP socket (POSIX / WinSock2).
// Supports broadcast discovery + multicast group join for the P2P swarm.
// ============================================================================
#pragma once
#include <cstdint>
#include <string>
#include "protocol.h"

#ifdef _WIN32
  #include <winsock2.h>
  #include <ws2tcpip.h>
  typedef SOCKET SockHandle;
  #define SOCK_INVALID INVALID_SOCKET
#else
  #include <sys/socket.h>
  #include <netinet/in.h>
  #include <arpa/inet.h>
  #include <unistd.h>
  #include <fcntl.h>
  #include <errno.h>
  typedef int SockHandle;
  #define SOCK_INVALID (-1)
#endif

namespace sg {

// Global WSAStartup guard for Windows
bool netPlatformInit();
void netPlatformShutdown();

class UdpSocket {
public:
    UdpSocket() = default;
    ~UdpSocket() { close(); }
    UdpSocket(const UdpSocket&) = delete;

    bool open(uint16_t port, bool allowBroadcast = true, bool joinMulticast = false);
    void close();
    bool isOpen() const { return sock != SOCK_INVALID; }
    uint16_t boundPort() const { return localPort; }

    // Returns bytes sent, -1 on error
    int sendTo(const void* data, size_t len, uint32_t ipBE, uint16_t port);
    int sendToAddr(const void* data, size_t len, const PeerAddr& a);
    int broadcast(const void* data, size_t len, uint16_t port);
    int multicast(const void* data, size_t len, uint16_t port);

    // Non-blocking receive. Returns bytes, 0 = nothing, -1 = error.
    int recvFrom(void* out, size_t cap, uint32_t& ipBE, uint16_t& port);

    static uint32_t ipFromString(const std::string& s);
    static std::string ipToString(uint32_t ipBE);

private:
    SockHandle sock = SOCK_INVALID;
    uint16_t localPort = 0;
};

// Multicast group used for discovery (administratively scoped)
constexpr uint32_t MULTICAST_GROUP = 0xEF1B2F27; // 239.27.47.47 big-endian stored
constexpr uint32_t BROADCAST_ADDR  = 0xFFFFFFFF; // 255.255.255.255

} // namespace sg
