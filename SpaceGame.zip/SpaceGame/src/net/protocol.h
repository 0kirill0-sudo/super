// ============================================================================
// protocol.h — SpaceGame P2P wire protocol.
// All packets: [magic u32 'SPGM'][ver u8][type u8][payload...]
// Little-endian, fixed layout, MTU-safe chunking for entity sync.
// ============================================================================
#pragma once
#include <cstdint>
#include <cstring>
#include <string>
#include <vector>
#include "../core/math3d.h"

namespace sg {

constexpr uint32_t NET_MAGIC   = 0x4D475053; // 'SPGM'
constexpr uint8_t  NET_VERSION = 3;
constexpr uint16_t NET_PORT_DEFAULT = 47477;
constexpr int      NET_MAX_PACKET   = 1300;  // keep under typical MTU with margin

enum PacketType : uint8_t {
    PKT_DISCOVER = 1,   // broadcast/multicast presence beacon
    PKT_HELLO,          // direct handshake request (carries peer info)
    PKT_WELCOME,        // handshake response
    PKT_REJECT,         // incompatible peer (version/seed mismatch)
    PKT_PEERS,          // peer-exchange gossip: known peer list
    PKT_SNAPSHOT,       // own ship state @ 20 Hz
    PKT_ENT_SYNC,       // sector-owner -> all: entity states (chunked)
    PKT_ENT_EVENT,      // damage / mine / kill requests to entity owner
    PKT_PROJ,           // projectile spawn (owner-simulated everywhere)
    PKT_BEACON,         // fleet ping marker
    PKT_CHAT,           // chat text
    PKT_PING,           // RTT probe
    PKT_PONG,
    PKT_BYE,            // graceful leave
};

enum EntityEventType : uint8_t {
    EV_DAMAGE = 1,      // apply damage to entity
    EV_MINE,            // mining tick on asteroid (ore extraction)
    EV_KILL_CONFIRM,    // owner confirms entity death (loot to killer)
    EV_REPAIR,          // station repair tick
};

// ---------------------------------------------------------------------------
// Byte stream writer/reader (no allocation surprises, bounds-checked)
struct ByteWriter {
    std::vector<uint8_t> buf;
    ByteWriter() { buf.reserve(512); }
    explicit ByteWriter(size_t reserve) { buf.reserve(reserve); }
    void u8(uint8_t v) { buf.push_back(v); }
    void u16(uint16_t v) { buf.push_back((uint8_t)(v & 0xFF)); buf.push_back((uint8_t)(v >> 8)); }
    void u32(uint32_t v) { for (int i = 0; i < 4; i++) buf.push_back((uint8_t)((v >> (8 * i)) & 0xFF)); }
    void u64(uint64_t v) { for (int i = 0; i < 8; i++) buf.push_back((uint8_t)((v >> (8 * i)) & 0xFF)); }
    void i64(int64_t v) { u64((uint64_t)v); }
    void f32(float v) { uint32_t x; memcpy(&x, &v, 4); u32(x); }
    void f64(double v) { uint64_t x; memcpy(&x, &v, 8); u64(x); }
    void vec3d(const Vec3d& v) { f64(v.x); f64(v.y); f64(v.z); }
    void vec3(const Vec3& v) { f32(v.x); f32(v.y); f32(v.z); }
    void quat(const Quat& q) { f32(q.x); f32(q.y); f32(q.z); f32(q.w); }
    void str(const std::string& s) {
        size_t n = s.size() < 63 ? s.size() : 63;
        u8((uint8_t)n);
        for (size_t i = 0; i < n; i++) u8((uint8_t)s[i]);
    }
    void raw(const void* p, size_t n) { const uint8_t* b = (const uint8_t*)p; for (size_t i = 0; i < n; i++) buf.push_back(b[i]); }
    size_t size() const { return buf.size(); }
};

struct ByteReader {
    const uint8_t* p;
    size_t n, pos = 0;
    bool ok = true;
    ByteReader(const void* data, size_t len) : p((const uint8_t*)data), n(len) {}
    bool need(size_t k) { if (pos + k > n) { ok = false; return false; } return true; }
    uint8_t u8() { if (!need(1)) return 0; return p[pos++]; }
    uint16_t u16() { if (!need(2)) return 0; uint16_t v = (uint16_t)(p[pos] | (p[pos + 1] << 8)); pos += 2; return v; }
    uint32_t u32() {
        if (!need(4)) return 0;
        uint32_t v = 0;
        for (int i = 0; i < 4; i++) v |= (uint32_t)p[pos + i] << (8 * i);
        pos += 4; return v;
    }
    uint64_t u64() {
        if (!need(8)) return 0;
        uint64_t v = 0;
        for (int i = 0; i < 8; i++) v |= (uint64_t)p[pos + i] << (8 * i);
        pos += 8; return v;
    }
    int64_t i64() { return (int64_t)u64(); }
    float f32() { uint32_t x = u32(); float v; memcpy(&v, &x, 4); return v; }
    double f64() { uint64_t x = u64(); double v; memcpy(&v, &x, 8); return v; }
    Vec3d vec3d() { Vec3d v; v.x = f64(); v.y = f64(); v.z = f64(); return v; }
    Vec3 vec3() { Vec3 v; v.x = f32(); v.y = f32(); v.z = f32(); return v; }
    Quat quat() { Quat q; q.x = f32(); q.y = f32(); q.z = f32(); q.w = f32(); return q; }
    std::string str() {
        uint8_t len = u8();
        std::string s;
        if (!need(len)) return s;
        s.assign((const char*)p + pos, len);
        pos += len;
        return s;
    }
};

// ---------------------------------------------------------------------------
// Payload structs (mirror of wire format)
struct PeerAddr {
    uint32_t ip = 0;      // network order v4
    uint16_t port = 0;
    bool operator==(const PeerAddr& o) const { return ip == o.ip && port == o.port; }
};

struct ShipSnapshot {
    uint64_t peerId = 0;
    uint32_t seq = 0;
    Vec3d pos;
    Vec3 vel;              // float precision is fine for velocity (<= few 1e3)
    Quat rot;
    uint8_t throttle = 0;  // 0..100
    uint8_t shield = 0, armor = 0, hull = 0;
    uint8_t fuel = 0, o2 = 0;
    uint16_t flags = 0;    // bit0 mining, bit1 boosting, bit2 charging jump, bit3 dead, bit4 evacuated
    float jumpCharge = 0;  // 0..1
    uint32_t colorHash = 0;
};

enum SnapshotFlag : uint16_t {
    SF_MINING   = 1 << 0,
    SF_BOOST    = 1 << 1,
    SF_JUMPCHG  = 1 << 2,
    SF_DEAD     = 1 << 3,
    SF_EVAC     = 1 << 4,
    SF_SHIELDUP = 1 << 5,
};

struct EntSyncItem {
    uint64_t entId = 0;
    uint8_t type = 0;       // EntityType
    Vec3d pos;
    Quat rot;
    uint32_t varSeed = 0;   // mesh/skin variant + rotation seed
    uint16_t hp = 0;
    uint16_t hpMax = 0;
    uint8_t state = 0;      // 0 alive, 1 depleted/dead, 2 dormant
    uint8_t aux = 0;        // ore type / anomaly kind / boss ring
    float scale = 1.f;
    Vec3 vel;               // for moving entities (leviathan)
};

struct ProjSpawn {
    uint64_t projId = 0;
    uint64_t ownerId = 0;   // peer that fired
    uint64_t targetId = 0;  // 0 = none; else entity/peer target (for homing)
    uint8_t kind = 0;       // 0 plasma, 1 missile, 2 leviathan bolt
    Vec3d pos;
    Vec3 vel;
    uint16_t dmg = 0;
    uint16_t lifeMs = 6000;
};

struct EntEvent {
    uint8_t evType = 0;
    uint64_t targetId = 0;  // entity id, or peerId for player damage (flag in evType)
    uint64_t sourceId = 0;
    uint16_t amount = 0;
    uint8_t isPlayerTarget = 0;
    uint8_t aux = 0;        // ore type for mining
};

struct ChatMsg {
    uint64_t from = 0;
    std::string fromName;
    std::string text;
};

// Header helpers
inline void writeHeader(ByteWriter& w, PacketType t) {
    w.u32(NET_MAGIC);
    w.u8(NET_VERSION);
    w.u8((uint8_t)t);
}
inline bool readHeader(ByteReader& r, PacketType& t, uint8_t& ver) {
    uint32_t magic = r.u32();
    ver = r.u8();
    t = (PacketType)r.u8();
    return r.ok && magic == NET_MAGIC;
}

} // namespace sg
