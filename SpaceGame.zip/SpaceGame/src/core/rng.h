// ============================================================================
// rng.h — Deterministic hashing RNG + value noise for procedural universe.
// The same (universeSeed, sectorId) always produces the same sector content
// on every peer — the foundation of serverless P2P world generation.
// ============================================================================
#pragma once
#include <cstdint>
#include <cmath>
#include "math3d.h"

namespace sg {

// splitmix64 — fast high-quality integer hash
inline uint64_t splitmix64(uint64_t x) {
    x += 0x9E3779B97F4A7C15ull;
    x = (x ^ (x >> 30)) * 0xBF58476D1CE4E5B9ull;
    x = (x ^ (x >> 27)) * 0x94D049BB133111EBull;
    return x ^ (x >> 31);
}

inline uint64_t hashCombine(uint64_t a, uint64_t b) {
    return splitmix64(a ^ (b + 0xD6E8FEB86659FD93ull + (a << 6) + (a >> 2)));
}

inline uint32_t hash3to32(int64_t x, int64_t y, int64_t z, uint64_t seed) {
    uint64_t h = (uint64_t)seed;
    h = hashCombine(h, (uint64_t)x * 0x2545F4914F6CDD1Dull);
    h = hashCombine(h, (uint64_t)y * 0x7A646E543B9A4E23ull);
    h = hashCombine(h, (uint64_t)z * 0x1B03738712BAD63ull);
    return (uint32_t)(h >> 32);
}

// Stateless per-stream random generator: Rng(seed, stream) -> [0,1)
struct Rng {
    uint64_t state;
    explicit Rng(uint64_t seed) : state(seed ? seed : 0x12345678ABCDEF01ull) {}
    Rng(uint64_t seed, uint64_t stream) : state(splitmix64(seed ^ splitmix64(stream))) {}

    uint64_t nextU64() { state = splitmix64(state); return state; }
    uint32_t nextU32() { return (uint32_t)(nextU64() >> 32); }
    float nextF() { return (float)((nextU64() >> 40) * (1.0 / 16777216.0)); }          // [0,1)
    float range(float lo, float hi) { return lo + (hi - lo) * nextF(); }
    int   irange(int lo, int hiIncl) { return lo + (int)(nextU64() % (uint64_t)(hiIncl - lo + 1)); }
    double nextD() { return (double)(nextU64() >> 11) * (1.0 / 9007199254740992.0); }
    // Uniform point in sphere
    Vec3 inUnitSphere() {
        Vec3 v(range(-1, 1), range(-1, 1), range(-1, 1));
        while (v.lenSq() > 1.f || v.lenSq() < 1e-8f) v = Vec3(range(-1, 1), range(-1, 1), range(-1, 1));
        return v;
    }
    Vec3d inUnitSphereD() {
        Vec3d v(range(-1, 1), range(-1, 1), range(-1, 1));
        while (v.lenSq() > 1.0 || v.lenSq() < 1e-8) v = Vec3d(range(-1, 1), range(-1, 1), range(-1, 1));
        return v;
    }
    Vec3 onUnitSphere() { return inUnitSphere().norm(); }
    Quat randQuat() {
        float u1 = nextF(), u2 = nextF() * TAU, u3 = nextF() * TAU;
        float s1 = std::sqrt(1.f - u1), s2 = std::sqrt(u1);
        return Quat(s1 * std::sin(u2), s1 * std::cos(u2), s2 * std::sin(u3), s2 * std::cos(u3)).norm();
    }
};

// ----------------------------------------------------------------------------
// Deterministic value noise (3D) + fbm. Seeded, identical on every peer.
inline float hashNoise3(float x, float y, float z, uint32_t seed) {
    int32_t ix = (int32_t)std::floor(x), iy = (int32_t)std::floor(y), iz = (int32_t)std::floor(z);
    float fx = x - (float)ix, fy = y - (float)iy, fz = z - (float)iz;
    fx = fx * fx * (3.f - 2.f * fx);
    fy = fy * fy * (3.f - 2.f * fy);
    fz = fz * fz * (3.f - 2.f * fz);
    auto lat = [&](int32_t dx, int32_t dy, int32_t dz) -> float {
        uint32_t h = hash3to32(ix + dx, iy + dy, iz + dz, seed);
        return (float)h * (1.f / 4294967295.f);
    };
    float x00 = lerpf(lat(0, 0, 0), lat(1, 0, 0), fx);
    float x10 = lerpf(lat(0, 1, 0), lat(1, 1, 0), fx);
    float x01 = lerpf(lat(0, 0, 1), lat(1, 0, 1), fx);
    float x11 = lerpf(lat(0, 1, 1), lat(1, 1, 1), fx);
    float y0 = lerpf(x00, x10, fy);
    float y1 = lerpf(x01, x11, fy);
    return lerpf(y0, y1, fz);
}

inline float fbm3(float x, float y, float z, uint32_t seed, int octaves = 4, float gain = 0.5f) {
    float amp = 1.f, freq = 1.f, sum = 0.f, norm = 0.f;
    for (int i = 0; i < octaves; i++) {
        sum += amp * hashNoise3(x * freq, y * freq, z * freq, seed + (uint32_t)i * 7919u);
        norm += amp;
        amp *= gain;
        freq *= 2.03f;
    }
    return sum / norm; // [0,1]
}

// Hash -> color helpers for deterministic ship/ore tinting
inline Vec3 hashColor(uint32_t h, float sat = 0.75f, float val = 1.f) {
    // HSV-ish from hash
    float hue = (float)(h % 360u) / 360.f;
    float c = val * sat;
    float x2 = c * (1.f - std::fabs(std::fmod(hue * 6.f, 2.f) - 1.f));
    float m = val - c;
    float r, g, b;
    int sect = (int)(hue * 6.f) % 6;
    switch (sect) {
        case 0: r = c; g = x2; b = 0; break;
        case 1: r = x2; g = c; b = 0; break;
        case 2: r = 0; g = c; b = x2; break;
        case 3: r = 0; g = x2; b = c; break;
        case 4: r = x2; g = 0; b = c; break;
        default: r = c; g = 0; b = x2; break;
    }
    return { r + m, g + m, b + m };
}

} // namespace sg
