// ============================================================================
// log.h — minimal timestamped logging (stdout + optional file)
// ============================================================================
#pragma once
#include <cstdio>
#include <cstdarg>
#include <ctime>
#include <mutex>

namespace sg {

enum LogLevel { LOG_INFO = 0, LOG_WARN, LOG_ERR };

class Log {
public:
    static Log& get() { static Log l; return l; }
    FILE* file = nullptr;
    bool quiet = false;
    std::mutex mtx;

    void openFile(const char* path) {
        if (!file) file = fopen(path, "a");
    }
    void write(LogLevel lvl, const char* fmt, va_list args) {
        std::lock_guard<std::mutex> g(mtx);
        const char* tag = lvl == LOG_ERR ? "ERR " : (lvl == LOG_WARN ? "WARN" : "INFO");
        time_t t = time(nullptr);
        struct tm tmv;
#ifdef _WIN32
        localtime_s(&tmv, &t);
#else
        localtime_r(&t, &tmv);
#endif
        char tbuf[16];
        strftime(tbuf, sizeof(tbuf), "%H:%M:%S", &tmv);
        char line[1024];
        vsnprintf(line, sizeof(line), fmt, args);
        if (!quiet) {
            fprintf(stdout, "[%s %s] %s\n", tbuf, tag, line);
            fflush(stdout);
        }
        if (file) {
            fprintf(file, "[%s %s] %s\n", tbuf, tag, line);
            fflush(file);
        }
    }
};

inline void logInfo(const char* fmt, ...) { va_list a; va_start(a, fmt); Log::get().write(LOG_INFO, fmt, a); va_end(a); }
inline void logWarn(const char* fmt, ...) { va_list a; va_start(a, fmt); Log::get().write(LOG_WARN, fmt, a); va_end(a); }
inline void logErr (const char* fmt, ...) { va_list a; va_start(a, fmt); Log::get().write(LOG_ERR,  fmt, a); va_end(a); }

} // namespace sg
